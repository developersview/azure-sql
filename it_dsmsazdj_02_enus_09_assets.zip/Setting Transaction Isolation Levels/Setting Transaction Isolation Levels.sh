				######## Isolation Transaction ##########

######## READ UNCOMMITTED ########

## Create a new notebook for sql_database and call it ClientOne
## Create a second notebook for sql_database and call it ClientTwo


## We begin with the notebook for ClientOne
# Creating a bank account details of Ms. Ken 
## The IDENTITY is a way to auto-assign and increment a value:
## https://learn.microsoft.com/en-us/sql/t-sql/statements/create-table-transact-sql-identity-property

CREATE SCHEMA Bank; 

CREATE TABLE [Bank].[AccountDetails]
(
  id INT PRIMARY KEY IDENTITY(1, 1), 
  acc_number VARCHAR(40), 
  acc_holder_name VARCHAR(100), 
  balance int
);

###

# Inserting the Data 

INSERT INTO [Bank].[AccountDetails]
VALUES
('7Z290387', 'Ken', '90');


## Check the table contents
SELECT * FROM [Bank].[AccountDetails]


## Check the Isolation level of your current client session
## The default is READ COMMITTED
SELECT @@SPID AS server_process_id, transaction_isolation_level
FROM [sys].[dm_exec_requests]
WHERE session_id = @@SPID


# 1 = READ UNCOMMITTED
# 2 = READ COMMITTED
# 3 = REPEATABLE READ
# 4 = SERIALIZABLE
# 5 = SNAPSHOT

####

# Step : 1

# Assume Ken has invoked a transaction to pay $45 to his grocery store
# We are writing the condition that, unfortunately if there is any lag 
# Then payment will roll back to his account after 2 mins
# https://learn.microsoft.com/en-us/sql/t-sql/language-elements/waitfor-transact-sql

## Paste this block of code in a single cell and run
BEGIN TRAN;
  UPDATE [Bank].[AccountDetails]
  SET balance = balance - 45
  WHERE acc_number = '7Z290387';

  WAITFOR DELAY '00:03:00';
ROLLBACK TRAN;


### We now switch over to the second notebook while the above transaction is still pending

## Head to the notebook for ClientTwo and check the isolation level

SELECT @@SPID AS server_process_id, transaction_isolation_level
FROM [sys].[dm_exec_requests]
WHERE session_id = @@SPID

## Check the balance for Ken's account - the uncommitted change cannot be seen
SELECT *
FROM [Bank].[AccountDetails]
WHERE acc_number = '7Z290387';


## Change the transaction isolation level to read uncommitted
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

## Now when the same query is run, we can read the uncommitted value of Ken's bank account
SELECT *
FROM [Bank].[AccountDetails]
WHERE acc_number = '7Z290387';


## Switch back to the notebook for ClientOne
## We wait for the suspended transaction to be rolled back
## Once it is done, check the account balance from Client One
SELECT *
FROM [Bank].[AccountDetails]
WHERE acc_number = '7Z290387';


## Switch to ClientTwo
## We check the balance again - we see the original value now
SELECT *
FROM [Bank].[AccountDetails]
WHERE acc_number = '7Z290387';




###### Repeatable Read #####

## We begin from ClientOne

## Add a new row of data for a customer, Tonya
INSERT INTO [Bank].[AccountDetails]
VALUES
('9Z199199', 'Tonya', '200');

## Confirm the insert
SELECT * FROM [Bank].[AccountDetails]


## Run this transaction from ClientOne

DECLARE @KenBalance int

BEGIN TRAN;

  SELECT @KenBalance = balance FROM [Bank].[AccountDetails] 
                               WHERE acc_holder_name = 'Ken';
  PRINT 'KenBalance before the delay is: ' + CAST(@KenBalance AS VARCHAR(16));

  WAITFOR DELAY '00:03:00';

  SELECT @KenBalance = balance FROM [Bank].[AccountDetails] 
                               WHERE acc_holder_name = 'Ken';
  PRINT 'KenBalance after the delay is: ' + CAST(@KenBalance AS VARCHAR(16));

ROLLBACK TRAN;


## While ClientOne is suspended, we head to ClientTwo's notebook

## We now try to modify Ken's balance from this client

## Run the following transaction before the delay in ClientOne expires
DECLARE @KenBalance int

BEGIN TRAN;

  SELECT @KenBalance = balance FROM [Bank].[AccountDetails] 
                               WHERE acc_holder_name = 'Ken';
  PRINT 'Initial balance for Ken: ' + CAST(@KenBalance AS VARCHAR(16));

  UPDATE [Bank].[AccountDetails]
  SET balance = balance - 45
  WHERE acc_holder_name = 'Ken';

  SELECT @KenBalance = balance FROM [Bank].[AccountDetails] 
                               WHERE acc_holder_name = 'Ken';
  PRINT 'Updated balance for Ken: ' + CAST(@KenBalance AS VARCHAR(16));

COMMIT TRAN;


## Switch back to ClientOne and wait for the delay to complete in the transaction
## The output will be something like this

KenBalance before the delay is: 90
KenBalance after the delay is: 45

## That is, reads within the same transaction give us back different values
## i.e. the read is not repeatable in the same transaction

## We can address this by changing the isolation level
## Run this chunk of code from ClientOne
## We do the same read operations but with the REPEATABLE READ isolation level

SET TRANSACTION ISOLATION LEVEL REPEATABLE READ;

DECLARE @KenBalance int;

BEGIN TRAN;

  SELECT @KenBalance = balance FROM [Bank].[AccountDetails] 
                               WHERE acc_holder_name = 'Ken';
  PRINT 'KenBalance before the delay is: ' + CAST(@KenBalance AS VARCHAR(16));

  WAITFOR DELAY '00:03:00';

  SELECT @KenBalance = balance FROM [Bank].[AccountDetails] 
                               WHERE acc_holder_name = 'Ken';
  PRINT 'KenBalance after the delay is: ' + CAST(@KenBalance AS VARCHAR(16));

ROLLBACK TRAN;


## While ClientOne is suspended, head back to ClientTwo 
## We now try to perform another update of Ken's balance
## The code is similar to what it was before, but the update amount is just 20

DECLARE @KenBalance int

BEGIN TRAN;

  SELECT @KenBalance = balance FROM [Bank].[AccountDetails] 
                               WHERE acc_holder_name = 'Ken';
  PRINT 'Initial balance for Ken: ' + CAST(@KenBalance AS VARCHAR(16));

  UPDATE [Bank].[AccountDetails]
  SET balance = balance - 20
  WHERE acc_holder_name = 'Ken';

  SELECT @KenBalance = balance FROM [Bank].[AccountDetails] 
                               WHERE acc_holder_name = 'Ken';
  PRINT 'Updated balance for Ken: ' + CAST(@KenBalance AS VARCHAR(16));

COMMIT TRAN;


## The update cannot take place now
## We get a message like this one:
Lock request time out period exceeded


## But we can modify other rows in the same table
## Tonya's balance can be updated while the lock is being held for Ken's row

DECLARE @TonyaBalance int

BEGIN TRAN;

  SELECT @TonyaBalance = balance FROM [Bank].[AccountDetails] 
                               WHERE acc_holder_name = 'Tonya';
  PRINT 'Initial balance for Tonya: ' + CAST(@TonyaBalance AS VARCHAR(16));

  UPDATE [Bank].[AccountDetails]
  SET balance = balance - 100
  WHERE acc_holder_name = 'Tonya';

  SELECT @TonyaBalance = balance FROM [Bank].[AccountDetails] 
                               WHERE acc_holder_name = 'Tonya';
  PRINT 'Updated balance for Tonya: ' + CAST(@TonyaBalance AS VARCHAR(16));

COMMIT TRAN;



