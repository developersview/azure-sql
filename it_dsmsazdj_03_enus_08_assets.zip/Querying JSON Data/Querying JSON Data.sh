######### Handling multiple data models #######

## Refer to the notebook WorkingWithJSON.ipynb for JSON-based data models

## Refer to the notebook WorkingWithGraphs.ipynb for graph data models

#############################

